package com.petsystem.pet_project.model;

public enum Role {
    ADMIN,
    PET_OWNER,
    VET
}
